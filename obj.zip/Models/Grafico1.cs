﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WFComercialWebApp.Models
{
    public class Grafico1
    {
        public string Fecha { get; set; }
        public Nullable<int> Centro { get; set; }
        public Nullable<int> Occidente { get; set; }
        public Nullable<int> Oriente { get; set; }

    }
}