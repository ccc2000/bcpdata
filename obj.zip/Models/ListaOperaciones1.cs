﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WFComercialWebApp.Models
{
    public class ListaOperaciones1
    {
        public string Ncliente { get; set;}
        public string FFRR { get; set; }
        public string Banca { get; set; }
        public string Region { get; set; }
        public string Sucursal { get; set; }
        public string Asunto { get; set; }
        public string Texto { get; set; }
        public int DiasP { get; set; }
        public int DiasB { get; set; }
        public int DiasR { get; set; }
        public DateTime FechaAprobacion { get; set; }



    }
}