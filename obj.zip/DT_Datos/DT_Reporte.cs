﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WFComercialWebApp.Models;

using System.Data.SqlClient;
using System.Data;

namespace WFComercialWebApp.DT_Datos
{
    public class DT_Reporte
    {


        public List<Grafico1> RetornarGrafico1()
        {
            List<Grafico1> objLista = new List<Grafico1>();

            //Data Source=;Initial Catalog= ; User ID= ; Password=
            using (SqlConnection oconexion = new SqlConnection("Data Source=BCRRBM00; Initial Catalog=LID_RIESG_COMERC; Integrated Security=True"))
            {
                string query = "SPoperacion";

                SqlCommand cmd = new SqlCommand(query, oconexion);
                cmd.CommandType = CommandType.StoredProcedure;

                oconexion.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        objLista.Add(new Grafico1()
                        {
                            Fecha = dr["Fecha"].ToString(),
                            Occidente = int.Parse(dr["Occidente"].ToString()),
                            // Vencida = Decimal.Parse(dr["Vencida"].ToString()),
                            Oriente = int.Parse(dr["Oriente"].ToString()),
                            Centro = int.Parse(dr["Centro"].ToString()),
                        });

                    }
                }
            }

            return objLista;
        }


        
        public List<ListaOperaciones1> ListarOperacion()
        {
            List<ListaOperaciones1> objLista2 = new List<ListaOperaciones1>();

            //Data Source=;Initial Catalog= ; User ID= ; Password=
            using (SqlConnection oconexion = new SqlConnection("Data Source=BCRRBM00; Initial Catalog=LID_RIESG_COMERC; Integrated Security=True"))
            {
                string query = "OperacionesL";

                SqlCommand cmd = new SqlCommand(query, oconexion);
                cmd.CommandType = CommandType.StoredProcedure;

                oconexion.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        objLista2.Add(new ListaOperaciones1()
                        {
                            Ncliente = dr["Ncliente"].ToString(),
                            FFRR = dr["FFRR"].ToString(),
                            Banca = dr["Banca"].ToString(),
                            Region = dr["Region"].ToString(),
                            Sucursal = dr["Sucursal"].ToString(),
                            Asunto = dr["Asunto"].ToString(),
                            Texto = dr["Texto"].ToString(),
                            DiasP = int.Parse(dr["DiasP"].ToString()),
                            // Vencida = Decimal.Parse(dr["Vencida"].ToString()),
                            DiasB = int.Parse(dr["DiasB"].ToString()),
                            DiasR = int.Parse(dr["DiasR"].ToString()),
                            FechaAprobacion = DateTime.Parse(dr["FechaAprobacion"].ToString()),
                        });

                    }
                }
            }

            return objLista2;
        }



        //hasta aqui

       
        //
    }
}